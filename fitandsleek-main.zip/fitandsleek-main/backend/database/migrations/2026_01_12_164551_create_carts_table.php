<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
  public function up(): void {
    Schema::create('carts', function (Blueprint $table) {
      $table->id();
      $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
      $table->uuid('session_id')->nullable()->index(); // for guests (optional)
      $table->string('status', 20)->default('active'); // active|converted
      $table->timestamps();
    });
  }

  public function down(): void {
    Schema::dropIfExists('carts');
  }
};
